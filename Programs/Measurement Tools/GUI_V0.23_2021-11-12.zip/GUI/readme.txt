/**
	Created by Daniel Schäfer, 2020 Sommer Semester
	Daniel.schaefer3@stud.fra-uas.de
**/
1.	Hardware
	A WLAN stick has to be attached at your PC. Tha stick
	has to be connected to the WLAN ID "Red Pitaya APxx", where xx
	represents the number of you device ( 00,...,99 ). The password should be
	"redpitaya".

2.	Software
	To start the program, just unpack the zip file and navigate to the recent folder.
	It is possible that you Virus Scanner is alerting. That should be ignored and the
	program should be added to the trusted applications.
	The binary file "UDP_Client.exe" has to be started.
	If the WLAN connection is successfully established, the GUI should show, that there is
	at least one active sensor. Now you can start the UDP-Client.
	
	enjoy!
﻿using Renci.SshNet;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using WinSCP;

namespace UDP_Client
{
    enum CT_t
    {
        ChartNone,
        ChartADC,
        ChartFFT
    };



    struct AppConfig_s
    {
        public String SensorIP1;
        public String SensorIP2;
        public int SensorPort;
        public int LocalPort;
        public bool ADCActive;
        public bool FFTActive;
        public int PlotCounter;
        public int PlotsMaximum;
        public bool SaveStreams;
        public int SaveStreamsCount;
        
        public void SetDefault( )
        {
            this.SensorIP1 = "192.168.128.1";
            this.SensorIP2 = "192.168.129.1";
            this.SensorPort = 6000;
            this.LocalPort = 6000;
            this.ADCActive = false;
            this.FFTActive = false;
            this.PlotCounter = 0;
            this.PlotsMaximum = 1;
            this.SaveStreams = false;
            this.SaveStreamsCount = 0;
            
        }
    }



    struct FFTConfig_s
    {
        public int MinFrequency;
        public int MinFrequencyIndex;
        public int MaxFrequency;
        public int MaxFrequencyIndex;
        public int DataCount;
        public int ColorCounter;
        public double SampleFrequency;
        public double SampleDecimation;
        public double FrequencyFactor;
        public bool SaveXValues;

        public FFTConfig_s(int MinFreq=35000, int MaxFreq=45000)
        {
            MinFrequency = MinFreq;
            MinFrequencyIndex = 0;
            MaxFrequency = MaxFreq;
            MaxFrequencyIndex = 10;
            DataCount = 10;
            ColorCounter = 0;
            UpdateSeries = true;
            SampleFrequency = 125 * Math.Pow(10, 6); // [Hz] --> 125 MHz
            SampleDecimation = 64;
            FrequencyFactor = -1;
            SaveXValues = false;
        }
        public void SetMinMaxFreq(int MinFreq, int MaxFreq)
        {
            MinFrequency = MinFreq;
            MaxFrequency = MaxFreq;
        }
        public void SetFrequency( double FreqFacIn, int MinFreqIx, int MaxFreqIx)
        {
            FrequencyFactor     = FreqFacIn;
            MinFrequencyIndex   = MinFreqIx;
            MaxFrequencyIndex   = MaxFreqIx;
            DataCount      = MaxFrequencyIndex - MinFrequencyIndex + 1;
        }
        public bool UpdateSeries { get; set; }
        //public int PlotsMaximum { get; set; }
        
    }



    struct ChartConfig_s
    {
        private double YMax;
        private double YMin;
        public double Y1;
        public double Y0;
        private double XMax;
        private double XMin;
        public double X1;
        public double X0;
        private CT_t Typ;
        private UInt32 XInc;
        private UInt32 YInc;
        public String XTitle;
        public String YTitle;

        public ChartConfig_s( double ValIn=0 )
        {
            YMax = ValIn;
            YMin = ValIn;
            Y0 = YMin;
            Y1 = YMax;
            XMax = ValIn;
            XMin = ValIn;
            X0 = XMin;
            X1 = XMax;
            XTitle = "X";
            YTitle = "Y";
            XInc = 500;
            YInc = 500;
            Typ = CT_t.ChartNone;
        }
        public void SetADC()
        {
            XMin = 0;
            XMax = 16000;
            YMin = -10000;
            YMax = +10000;
            XInc = 500;
            YInc = 1000;
            XTitle = "Samples [-]";
            YTitle = "decimal Values";
            if(Typ != CT_t.ChartADC)
            {
                Typ = CT_t.ChartADC;
                ScaleShiftReset();
            }
        }

        public void SetFFT()
        {
            XMin = 35000;
            XMax = 45000;
            YMin = Double.NaN;
            YMax = Double.NaN;
            XInc = 1000;
            YInc = 1000;
            XTitle = "Frequency [Hz]";
            YTitle = "Amplitude sqrt(re² + im²)";
            if(Typ != CT_t.ChartFFT)
            {
                Typ = CT_t.ChartFFT;
                ScaleShiftReset();
            }
        }

        public void ScaleX( bool ScaleOut=true)
        {
            if (ScaleOut){
                if( (X1 < XMax) && (X0 > XMin))
                {
                    X1 += XInc;
                    X0 -= XInc;
                }
            }
            else{
                if( X1 >= (X0 + 4 * XInc))
                {
                    X1 -= XInc;
                    X0 += XInc;
                }
            }
        }

        public void ScaleY( bool ScaleOut = true)
        {
            if (ScaleOut){
                if ((Y1 < YMax) && (Y0 > YMin)){
                    Y1 += YInc;
                    Y0 -= YInc;
                }
            }
            else{
                if (Y1 >= (Y0 + 4 * YInc)){
                    Y1 -= YInc;
                    Y0 += YInc;
                }
            }
        }

        public void ShiftX( bool ShiftLeft = true)
        {
            if (ShiftLeft){
                if(X0 >= (XMin + XInc)) {
                    X0 -= XInc;
                    X1 -= XInc;
                }
            }
            else{
                if(X1 <= (XMax - XInc)){
                    X1 += XInc;
                    X0 += XInc;
                }
            }
        }

        public void ShiftY( bool ShiftUp = true)
        {
            if (ShiftUp)
            {
                if(Y1 <= (YMax - YInc))
                {
                    Y1 += YInc;
                    Y0 += YInc;
                }
            }
            else
            {
                if(Y0 >= (YMin + YInc))
                {
                    Y0 -= YInc;
                    Y1 -= YInc;
                }
            }
        }

        public void ScaleShiftReset()
        {
            X0 = XMin;
            X1 = XMax;
            Y0 = YMin;
            Y1 = YMax;
        }

    }



    public partial class Form1 : Form
    {
        internal static Form1 FM1 = null;


        Ping RP_Ping = null;
        SshClient RP_Client1 = null;
        SshClient RP_Client2 = null;
        Thread UDP_Thread1 = null;
        WinSCP.Session SCP_Client = null;
        WinSCP.SessionOptions[] SCP_Options_Sensor = new SessionOptions[2] { null, null };
        UInt32 rx_count;
        String HostName;
        IPAddress[] HostIP;


        // UDP variables
        IPEndPoint EndPoint1 = null;
        IPEndPoint EndPoint2 = null;
        IPEndPoint UDP_EP_Local = null;
        UdpClient UDP_Sock = null;

        int PlotCounterOld = 0;

        //readonly Color[] StatusColor = { Color.DarkGreen, Color.Green, Color.Yellow, Color.Red };
        readonly Color[] MyColor = { Color.Red, Color.Blue, Color.Green, Color.Orange,
                                     Color.DarkRed, Color.DarkBlue, Color.DarkGreen, Color.DarkOrange,
                                     Color.LightPink, Color.LightBlue, Color.LightGreen, Color.MediumOrchid};
        readonly String RPProgPath = "/root/redpitaya/Examples/Communication/C/iic";
        readonly String[] LearnObjects = { "nothing", "Wall", "Ceiling","HiFi board", "Human" };
        readonly int FFT_MAX_FREQ = 45000;
        readonly int FFT_MIN_FREQ = 35000;

        String ProgramDir = "";
        String WorkingDir = "";
        String DataSaveDir = "";
        String DataSaveDirFFT = "";
        String DataSaveDirADC = "";
        String ActualSaveFile = "";
        String ActualFeatureSaveFile = "";

        UInt16[] XValues = { };

        AppConfig_s AppConfig = new AppConfig_s();
        FFTConfig_s FFTConfig = new FFTConfig_s(35000,45000);
        ChartConfig_s ChartConfig = new ChartConfig_s();



        // start up / initialize
        public Form1()
        {
            InitializeComponent();
        }
        


        private void Form1_Load(object sender, EventArgs e)
        {
            // restore permanent saved values
            // #####################################
            FFTConfig.SetMinMaxFreq(Properties.Settings.Default.FFTMinFrequency, Properties.Settings.Default.FFTMaxFrequency);
            AppConfig.SetDefault();
            // #####################################
            // end

            FM1 = this;

            RP_Ping = new Ping();
            SCP_Client = new WinSCP.Session();
            SCP_Options_Sensor[0] = new WinSCP.SessionOptions{ Protocol = Protocol.Scp, HostName = AppConfig.SensorIP1, UserName = "root", Password = "root", GiveUpSecurityAndAcceptAnySshHostKey = true, PortNumber = 22, };
            SCP_Options_Sensor[1] = new WinSCP.SessionOptions{ Protocol = Protocol.Scp, HostName = AppConfig.SensorIP2, UserName = "root", Password = "root", GiveUpSecurityAndAcceptAnySshHostKey = true, PortNumber = 22, };
            RP_Client1 = new SshClient(AppConfig.SensorIP1, 22, "root", "root");
            RP_Client2 = new SshClient(AppConfig.SensorIP2, 22, "root", "root");

            HostName = Environment.MachineName;

            EndPoint1 = new IPEndPoint(IPAddress.Parse(AppConfig.SensorIP1), (int)AppConfig.SensorPort);
            EndPoint2 = new IPEndPoint(IPAddress.Parse(AppConfig.SensorIP2), (int)AppConfig.SensorPort);
            UDP_EP_Local = new IPEndPoint(IPAddress.Any, (int)AppConfig.LocalPort);

            UDP_Sock = new UdpClient(UDP_EP_Local);

            // set all necessary directories
            SetWorkingDirectories(Directory.GetCurrentDirectory());

            // set IP-addresses
            TextBoxRemoteIP1.Text = AppConfig.SensorIP1;
            TextBoxRemotePort1.Text = AppConfig.SensorPort.ToString();

            CbLearnObject.Items.Clear();
            for(int ix=0; ix<LearnObjects.Length; ix++)
            {
                CbLearnObject.Items.Add(LearnObjects[ix]);
            }
            CbLearnObject.SelectedIndex = 1;


            TextBoxTX.Text = "-c";
            LabelRXcount.Text = "0";
            LabelVersionInfo.Text = "V0.XXx";
            

            ButtonCheckServer.PerformClick();
        }



        // button actions / functions
        private void ButtonTX_Click(object sender, EventArgs e)
        {
            UDPSendData1(TextBoxTX.Text);
        }



        private void ButtonRX_Click(object sender, EventArgs e)
        {
            TextBoxRX.Text = "";
            rx_count = 0;
            LabelRXcount.Text = Convert.ToString( rx_count );
        }



        private void ButtonCheckServer_Click(object sender, EventArgs e)
        {
            bool active;
            HostIP = Dns.GetHostAddresses(Environment.MachineName);
            int ret = PingServer();
            active = (ret > 0) ? (true) : (false);

            for (int ix = 0; ix < HostIP.Length; ix++)
            {
                HostName = HostIP[ix].ToString();
                if (HostName.Contains(AppConfig.SensorIP1.Substring(0, 11)))
                {
                    TextBoxLocalIP1.Text = HostIP[ix].ToString();
                }
            }

            ButtonStartClient.Enabled = active;
            ButtonProgramRP.Enabled = active;
            ButtonStartServer.Enabled = active;
            ButtonStopServer.Enabled = active;

            if (ret == 1)
            {
                SetStatus("sensor 1 active!");
            }
            else if (ret == 2)
            {
                SetStatus("sensor 2 active!");
            }
            else if( ret == 3)
            {
                SetStatus("sensor 1 and 2 active!");
            }
            else
            {
                SetStatus("sensor both inactive!");
            }
        }



        private void ButtonStartX_Click(object sender, EventArgs e)
        {
            CheckBox CBIn = (CheckBox)sender;
            String ButtonIn = CBIn.Name;
            bool Checked = CBIn.Checked;
            String Cmd;

            ButtonStartADC.Enabled = !Checked;
            ButtonStartFFT.Enabled = !Checked;
            ButtonStartMeasure.Enabled = !Checked;

            switch (ButtonIn)
            {
                case "ButtonStartMeasure":
                    CBIn.Text = (Checked) ? ("stop measure") : ("start measure");
                    Cmd = (Checked) ? ("-s 1") : ("-s 0");
                    UDPSendData1(Cmd);
                    break;

                case "ButtonStartFFT":
                    CBIn.Text = (Checked) ? ("stop FFT") : ("start FFT");
                    StartFFT(Checked);
                    break;

                case "ButtonStartADC":
                    CBIn.Text = (Checked) ? ("stop ADC") : ("start ADC");
                    StartADC(Checked);
                    break;


                default:
                    break;
            }

            CBIn.Enabled = true;

        }



        private void ButtonStartServer_Click(object sender, EventArgs e)
        {
            SShSendData("cd redpitaya/Examples/Communication/C/iic & sudo nice -n 10 ./iic");
        }



        private void ButtonStopServer_Click(object sender, EventArgs e)
        {
            SShSendData("pkill iic");
        }



        private void ButtonProgramRP_Click(object sender, EventArgs e)
        {
            String tx_data = ProgramDir;
            int ret = PingServer();

            SetStatus("working");
            SShSendData("pkill iic");
            for( int ix=0; ix<2; ix++)
            {
                if ( ( ret & (1 << ix)  ) != 0)
                {
                    SCP_Client.Open(SCP_Options_Sensor[ix]);
                    SetStatus("removing old data");
                    if (SCP_Client.FileExists("*iic")){
                        SCP_Client.RemoveFile("iic");
                    }
                    SetStatus("reprogramming sensor: " + ret.ToString());
                    SCP_Client.PutFilesToDirectory(tx_data, RPProgPath, "*.*", false, null);
                    SCP_Client.Close();
                }
            }
            SetStatus("make iic");
            SShSendData("make");
            
        }



        private void ButtonStartClient_CheckedChanged(object sender, EventArgs e)
        {
            bool Checked = ((CheckBox)sender).Checked;

            FFTConfig.UpdateSeries = Checked;
            BoxConfig.Enabled = !Checked;
            BoxRxTx.Enabled = Checked;
            BoxChart.Enabled = Checked;

            if (Checked)
            {

                CBSaveLearningData.Checked = !Checked;
                ButtonStartClient.Text = "stop client";
                StartUdpThread();
            }
            else
            {
                ButtonStartClient.Text = "start client";
                StartUdpThread(false);
            }
        }
        


        private void ButtonCopyClip_Click(object sender, EventArgs e)
        {
            if (TextBoxRX.Text.Length > 5)
            {
                Clipboard.SetText(TextBoxRX.Text.Replace(".", ","));
            }
        }



        private void ButtonExit_Click(object sender, EventArgs e)
        {
            try
            {
                UDP_Sock.Close();
                if (UDP_Thread1.IsAlive)
                {
                    UDP_Thread1.Abort();
                }
            }
            catch { }

            Application.Exit();
        }



        private void ButtonScaleX(object sender, EventArgs e)
        {
            Button ButIn = (Button)sender;
           

            switch (ButIn.Name)
            {
                // scaling operations
                case "ButtonScaleMinus":
                    ChartConfig.ScaleX(true);
                    break;

                case "ButtonScalePlus":
                    ChartConfig.ScaleX(false);
                    break;

                case "ButtonScaleZero":
                    ChartConfig.ScaleShiftReset();
                    break;

                // shifting operations
                case "ButtonShiftLeft":
                    ChartConfig.ShiftX(true);
                    break;

                case "ButtonShiftRight":
                    ChartConfig.ShiftX(false);
                    break;

                case "ButtonYZoomIn":
                    ChartConfig.ScaleY(false);
                    break;
                case "ButtonYZoomOut":
                    ChartConfig.ScaleY(true);
                    break;
                default:
                    break;
            }

            SetChartFFT();
        }



        // ##########################################
        // Thread function
        // ##########################################

        public bool StartUdpThread(bool Start = true)
        {
            if (Start)
            {
                UDP_Thread1 = new Thread(new ThreadStart(UDPThreadFunction1));
                UDP_Thread1.Start();
            }
            else
            {
                UDP_Thread1.Abort();
            }
            return Start;
        }



        public void UDPThreadFunction1()
        {
            String Mode;

            while (true)
            {
                Byte[] ByteBuffer = { };
                Byte[] DataBuffer = { };
                bool WriteDataToRx;
                int ByteBufferLength;
                int DataBufferCounter;
                string RXTemp;
                Mode = "";

                try
                {
                    // go into blocked mode and wait for control bytes (3 bytes)
                    //ByteBufferLength = UDP_Sock.Receive(ref LocalEP);
                    ByteBuffer = UDP_Sock.Receive(ref UDP_EP_Local);
                    
                    ByteBufferLength = ByteBuffer.Length;
                    WriteDataToRx = false;

                    if (ByteBuffer.Length == 3)
                    {
                        Mode = (Encoding.UTF8.GetString(ByteBuffer, 0, 3));

                        // go into blocked mode and wait for Payload ( n bytes )
                        ByteBuffer = UDP_Sock.Receive(ref UDP_EP_Local);
                        DataBuffer = new byte[ByteBuffer.Length];
                        ByteBuffer.CopyTo(DataBuffer, 0);
                        DataBufferCounter = DataBuffer.Length;

                        switch (Mode)
                        {
                            case "--c":
                                RXTemp = (Encoding.UTF8.GetString(DataBuffer, 0, DataBufferCounter));
                                string[] RxTempSplit = (RXTemp.Replace(',', '.')).Split(';');
                                FFTConfig.SetFrequency(Convert.ToDouble((RxTempSplit[0]).Replace('.', ',')), Convert.ToInt32(RxTempSplit[1]), Convert.ToInt32(RxTempSplit[2]));
                                MethodInvoker QuestionDelegate = delegate
                                {
                                    LabelVersionInfo.Text = RxTempSplit[3];
                                };
                                Invoke(QuestionDelegate);
                                break;
                            case "--s":
                                if (!BGFillData.IsBusy)
                                {
                                    BGFillData.RunWorkerAsync(DataBuffer);
                                }
                                else
                                {
                                    BGFillData2.RunWorkerAsync(DataBuffer);
                                }
                                break;
                            case "--f":
                                if (AppConfig.SaveStreams)
                                {
                                    BgFeatureWrite.RunWorkerAsync(DataBuffer);
                                }
                                WriteDataToRx = true;
                                break;
                            case "--m":
                                WriteDataToRx = true;
                                break;
                            default:
                                break;
                        } // end switch(mode)


                        if (WriteDataToRx)
                        {
                            WriteDataToRx ^= true;
                            RXTemp = (Encoding.UTF8.GetString(DataBuffer, 0, DataBufferCounter));
                            rx_count += 1;

                            MethodInvoker QuestionDelegate = delegate
                            {
                                TextBoxRX.AppendText(RXTemp + "\n");
                                LabelRXcount.Text = rx_count.ToString();
                                TextBoxRX.ScrollToCaret();
                                LabelRxByteCounter.Text = DataBufferCounter.ToString();
                            };
                            Invoke(QuestionDelegate);
                        }

                    }
                }
                catch { }
            }
        }



        public void UDPSendData1(string tx_data)
        {
            Byte[] sendBytes = Encoding.ASCII.GetBytes(tx_data);
            UDP_Sock.Send(sendBytes, sendBytes.Length, EndPoint1);
        }



        public int SShSendData( string tx_data )
        {
            int ret = PingServer();
            if ( ret > 0 )
            {

                if( (ret & 0x02)!=0 )
                {
                    RP_Client2.Connect();
                    RP_Client2.RunCommand(tx_data);
                    RP_Client2.Disconnect();
                }
                
                if( (ret & 0x01) != 0)
                {
                    RP_Client1.Connect();
                    RP_Client1.RunCommand(tx_data);
                    RP_Client1.Disconnect();
                }
                return 0;
            }
            else
            {
                return -1;
            }
        }



        public int SCPSendData( string tx_data)
        {

            return (0);
        }



        // Background Worker(s)
        private void BGFillData_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            byte[] DataBufferTmp = (byte[])(e.Argument);
            int DataBufferCounterTmp = DataBufferTmp.Length;

            MethodInvoker QuestionDelegate = delegate
            {
                if (AppConfig.ADCActive)
                {
                    CreateADCSeries(DataBufferTmp, DataBufferCounterTmp);
                    if (AppConfig.SaveStreams)
                    {
                        if (--AppConfig.SaveStreamsCount == 0)
                        {
                            ButtonStartADC.Checked = false;
                        }
                    }
                }
                else
                {
                    CreateFFTSeries(DataBufferTmp);
                    if (AppConfig.SaveStreams)
                    {
                        if( --AppConfig.SaveStreamsCount == 0)
                        {
                            ButtonStartFFT.Checked = false;
                        }
                    }
                }

                LabelPlotCount.Text = (++AppConfig.PlotCounter).ToString();
                LabelRxByteCounter.Text = DataBufferCounterTmp.ToString();
            };
            Invoke(QuestionDelegate);
        }



        private void BGFillData2_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            byte[] DataBufferTmp = (byte[])(e.Argument);
            int DataBufferCounterTmp = DataBufferTmp.Length;

            MethodInvoker QuestionDelegate = delegate
            {
                if (AppConfig.ADCActive)
                {
                    CreateADCSeries(DataBufferTmp, DataBufferCounterTmp);
                    if (AppConfig.SaveStreams)
                    {
                        if (--AppConfig.SaveStreamsCount == 0)
                        {
                            ButtonStartADC.Checked = false;
                        }
                    }
                }
                else
                {
                    CreateFFTSeries(DataBufferTmp);
                    if (AppConfig.SaveStreams)
                    {
                        if (--AppConfig.SaveStreamsCount == 0)
                        {
                            ButtonStartFFT.Checked = false;
                        }
                    }
                }

                LabelPlotCount.Text = (++AppConfig.PlotCounter).ToString();
                LabelRxByteCounter.Text = DataBufferCounterTmp.ToString();
            };
            Invoke(QuestionDelegate);
        }



        private void BgFeatureWrite_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            MethodInvoker QuestionDelegate = delegate
            {
                string tmp = Encoding.UTF8.GetString((byte[])(e.Argument), 0, ((byte[])(e.Argument)).Length);
                tmp += "\t" + CbLearnObject.SelectedItem.ToString() + "\n";
                File.AppendAllText(ActualFeatureSaveFile, tmp);
            };
            Invoke(QuestionDelegate);
        }



        // Private functions
        private int PingServer()
        {
            IPStatus stat;
            int ret = 0 ;


            stat = RP_Ping.Send(TextBoxRemoteIP1.Text, 50, Encoding.ASCII.GetBytes("0")).Status;
            ret |= (stat == IPStatus.Success) ? (0x01) : (0x00);

            return (ret);
        }



        private void TextBoxTX_TextChanged(object sender, EventArgs e)
        {
            ButtonTX.Enabled = (TextBoxTX.Text.Length >= 2);
        }



        private void LabelWorkingDir_Click(object sender, EventArgs e)
        {
            //folderBrowserDialog1.RootFolder = Environment.SpecialFolder.DesktopDirectory;
            folderBrowserDialog1.SelectedPath = Directory.GetCurrentDirectory();
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                SetWorkingDirectories(folderBrowserDialog1.SelectedPath);
            }
        }



        private void LabelOpenWorkingDir_Click(object sender, EventArgs e)
        {
            Process.Start(WorkingDir);
        }



        private void LabelOpenProgramDir_Click(object sender, EventArgs e)
        {
            Process.Start(ProgramDir);
        }



        private void LabelOpenDataDir_Click(object sender, EventArgs e)
        {
            Process.Start(DataSaveDir);
        }



        private void SetWorkingDirectories(String data_in)
        {
            WorkingDir = data_in;
            ProgramDir = WorkingDir + "\\proc";
            DataSaveDir = WorkingDir + "\\save";
            DataSaveDirADC = DataSaveDir;// + "\\ADC";
            DataSaveDirFFT = DataSaveDir;// + "\\FFT";
            Directory.CreateDirectory(ProgramDir);
            Directory.CreateDirectory(DataSaveDirADC);
            Directory.CreateDirectory(DataSaveDirFFT);
            LabelWorkingDir.Text = WorkingDir;
            LabelProgramDir.Text = ProgramDir;
            LabelDataDir.Text = DataSaveDir;
        }

        

        private void SetStatus(String data_in, bool action=true, int mSec=3000)
        {
            LableStatusGlobal.Text = "status: " + data_in;
            if (action)
            {
                LableStatusGlobal.ForeColor = Color.Blue;
            }
            else
            {
                LableStatusGlobal.ForeColor = Color.Black;
            }
            
            T1.Stop();
            T1.Enabled = true;
            T1.Interval = mSec;
            T1.Start();
        }



        // Timer function(s)
        private void T1_Tick(object sender, EventArgs e)
        {
            SetStatus("idle", false);
            T1.Stop();
            T1.Enabled = false;
        }



        // Chart / Series function(s)
        private void SetChartFFT( )
        {
            ChartArea CA = ChartFFT.ChartAreas[0];

            // X-Axis
            CA.IsSameFontSizeForAllAxes = true;
            CA.AxisX.TitleForeColor = Color.Green;
            CA.AxisX.MajorGrid.LineColor = Color.SlateGray;
            CA.AxisX.MinorGrid.Enabled = true;
            CA.AxisX.MinorGrid.LineColor = Color.LightGray;
            CA.AxisX.Title = ChartConfig.XTitle;
            CA.AxisX.Minimum = ChartConfig.X0;
            CA.AxisX.Maximum = ChartConfig.X1;
            CA.AxisX.Interval = (CA.AxisX.Maximum - CA.AxisX.Minimum) / 8;
            CA.AxisX.MinorGrid.Interval = CA.AxisX.Interval / 5;

            // Y-Axis
            CA.AxisY.TitleForeColor = Color.Green;
            CA.AxisY.MajorGrid.LineColor = Color.SlateGray;
            CA.AxisY.MinorGrid.Enabled = true;
            CA.AxisY.MinorGrid.LineColor = Color.LightGray;
            CA.AxisY.Title = ChartConfig.YTitle;
            CA.AxisY.Minimum = ChartConfig.Y0;
            CA.AxisY.Maximum = ChartConfig.Y1;
            CA.AxisY.IsStartedFromZero = true;
            CA.AxisY.MajorGrid.Interval = CA.AxisY.Maximum / 5;
            CA.AxisY.MinorGrid.Interval = CA.AxisY.MajorGrid.Interval / 2;

            XValues = new UInt16[FFTConfig.DataCount];
            for(int ix=0; ix<FFTConfig.DataCount; ix++)
            {
                XValues[ix] = (UInt16)( (ix + FFTConfig.MinFrequencyIndex) * FFTConfig.FrequencyFactor);
            }



            TextBoxFreqMin.Text = FFT_MIN_FREQ.ToString();
            TextBoxFreqMax.Text = FFT_MAX_FREQ.ToString();
        }



        private bool CreateFFTSeries(byte[] Data)
        {
            int DataLength = FFTConfig.DataCount * 2;
            bool ret = false;
            //double m = FFTConfig.FrequencyFactor;
            String temp = "";
            Series SeriesUpdate = new Series();

            UInt16[] YValues = new UInt16[DataLength / 2];

            for (int ix = 0; ix < (DataLength); ix += 2)
            {
                
                YValues[ix / 2] = BitConverter.ToUInt16(Data, ix);
                if (AppConfig.SaveStreams)
                {
                    temp += YValues[ix / 2].ToString() + "\t";
                }
            }

            SeriesUpdate.ChartType      = SeriesChartType.Line;
            SeriesUpdate.BorderWidth    = 1;
            SeriesUpdate.Points.DataBindXY(XValues, YValues);
            ChartFFT.Series.Add(SeriesUpdate);
            while (ChartFFT.Series.Count > 3)
            {
                ChartFFT.Series.RemoveAt(0);
            }
            ChartFFT.ChartAreas[0].RecalculateAxesScale();


            if( AppConfig.SaveStreams)
            {
                temp += "\n";
                File.AppendAllText(ActualSaveFile, temp);
            }

            return ret;
        }



        private bool CreateADCSeries(byte[] Data, int DataLength)
        {
            bool ret = false;
            Series SeriesUpdate = new Series();
            String temp = "";

            Int16[] YValues = new Int16[DataLength / 2];

            for (int ix = 0; ix < (DataLength); ix += 2)
            {
                YValues[ix / 2] = BitConverter.ToInt16(Data, ix);
                if (AppConfig.SaveStreams)
                {
                    temp += YValues[ix / 2].ToString() + "\t";
                }
            }
            
            while (ChartFFT.Series.Count > AppConfig.PlotsMaximum)
            {
                ChartFFT.Series.RemoveAt(0);
            }
            FFTConfig.ColorCounter++;
            SeriesUpdate.ChartType = SeriesChartType.Line;
            SeriesUpdate.BorderWidth = 1;
            SeriesUpdate.Points.DataBindY( YValues);
            ChartFFT.Series.Add(SeriesUpdate);

            SeriesUpdate.Color = MyColor[FFTConfig.ColorCounter % (MyColor.Length)];

            if (AppConfig.SaveStreams)
            {
                temp += "\n";
                File.AppendAllText(ActualSaveFile, temp);
                //SaveDataFromStream();
            }

            return ret;
        }



        private void TimerRxSpeed_Tick(object sender, EventArgs e)
        {
            LabelPlotSpeed.Text = Convert.ToString( (AppConfig.PlotCounter - PlotCounterOld)/ (TimerRxSpeed.Interval/1000) );
            PlotCounterOld = AppConfig.PlotCounter;
        }



        private void StartFFT(bool Checked)
        {

            if (Checked)
            {
                ActualSaveFile = DataSaveDirFFT + "\\fft_" + TbComment.Text + "_" + CbLearnObject.SelectedItem + "_" + BoxMaxFiles.Text + "_meas_data.txt";
                ActualFeatureSaveFile = DataSaveDirFFT + "\\fft_" + TbComment.Text + "_" + CbLearnObject.SelectedItem + "_" + BoxMaxFiles.Text + "_meas_features.txt";
                AppConfig.ADCActive = false;
                AppConfig.FFTActive = true;
                AppConfig.SaveStreams = CBSaveLearningData.Checked;
                AppConfig.SaveStreamsCount = Convert.ToInt32(BoxMaxFiles.Text);
                ChartConfig.SetFFT();
                SetChartFFT();
                if (!(File.Exists(ActualSaveFile)) && (AppConfig.SaveStreams))
                {
                    string tmp = "";
                    for (int ix = FFTConfig.MinFrequencyIndex; ix <= FFTConfig.MaxFrequencyIndex; ix++)
                    {
                        tmp += ((int)(ix * FFTConfig.FrequencyFactor)).ToString() + "\t";
                    }
                    tmp += "\n";
                    File.AppendAllText(ActualSaveFile, tmp);
                }
                PlotCounterOld = 0;
                TimerRxSpeed.Interval = 2000;
                FFTConfig.UpdateSeries = false;
                FFTConfig.SaveXValues = true;
                AppConfig.PlotsMaximum = 5;
                AppConfig.PlotCounter = 0;
                LabelPlotCount.Text = AppConfig.PlotCounter.ToString();
                TimerRxSpeed.Start();
                UDPSendData1("-f 1 " + CbLearnObject.SelectedIndex.ToString());
            }
            else
            {
                UDPSendData1("-f 0");
                CBSaveLearningData.Checked = false;
                AppConfig.FFTActive = false;
                TimerRxSpeed.Stop();
            }
        }



        private void StartADC(bool Checked=true)
        {
            
            if (Checked)
            {
                ActualSaveFile = DataSaveDirADC + "\\adc_" + TbComment.Text + "_" + BoxMaxFiles.Text + "x.txt";
                AppConfig.ADCActive = true;
                AppConfig.FFTActive = false;
                AppConfig.SaveStreams = CBSaveLearningData.Checked;
                AppConfig.SaveStreamsCount = Convert.ToInt32(BoxMaxFiles.Text);
                AppConfig.PlotsMaximum = (AppConfig.SaveStreams) ? (1) : (3);
                AppConfig.PlotCounter = 0;
                LabelPlotCount.Text = AppConfig.PlotCounter.ToString();
                ChartConfig.SetADC();
                SetChartFFT();
                UDPSendData1("-a 1");
            }
            else
            {
                AppConfig.SaveStreams = Checked;
                UDPSendData1("-a 0");
            }
        }



        private void label8_Click(object sender, EventArgs e)
        {
            Process.Start(DataSaveDir);
        }



        private void LabelVersionInfo_Click(object sender, EventArgs e)
        {
            Process.Start(ProgramDir + "\\iic.c");
        }


        
        private void CBSaveLearningData_CheckedChanged(object sender, EventArgs e)
        {
            GPLearn.Enabled = ((CheckBox)sender).Checked;
        }

        
    }


}

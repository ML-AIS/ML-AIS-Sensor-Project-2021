﻿namespace UDP_Client
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.BoxConfig = new System.Windows.Forms.GroupBox();
            this.ButtonProgramRP = new System.Windows.Forms.Button();
            this.ButtonStopServer = new System.Windows.Forms.Button();
            this.ButtonStartServer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ButtonCheckServer = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TextBoxRemotePort1 = new System.Windows.Forms.TextBox();
            this.TextBoxLocalIP1 = new System.Windows.Forms.TextBox();
            this.TextBoxRemoteIP1 = new System.Windows.Forms.TextBox();
            this.BoxRxTx = new System.Windows.Forms.GroupBox();
            this.GPLearn = new System.Windows.Forms.GroupBox();
            this.BoxMaxFiles = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CbLearnObject = new System.Windows.Forms.ComboBox();
            this.TbComment = new System.Windows.Forms.TextBox();
            this.ButtonStartADC = new System.Windows.Forms.CheckBox();
            this.ButtonStartFFT = new System.Windows.Forms.CheckBox();
            this.ButtonStartMeasure = new System.Windows.Forms.CheckBox();
            this.LabelRxByteCounter = new System.Windows.Forms.Label();
            this.LabelRXcount = new System.Windows.Forms.Label();
            this.CBSaveLearningData = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ButtonCopyClip = new System.Windows.Forms.Button();
            this.ButtonRxReset = new System.Windows.Forms.Button();
            this.TextBoxRX = new System.Windows.Forms.RichTextBox();
            this.ButtonTX = new System.Windows.Forms.Button();
            this.TextBoxTX = new System.Windows.Forms.TextBox();
            this.ButtonStartClient = new System.Windows.Forms.CheckBox();
            this.ButtonExit = new System.Windows.Forms.Button();
            this.BoxInformation = new System.Windows.Forms.GroupBox();
            this.LabelDataDir = new System.Windows.Forms.Label();
            this.LabelProgramDir = new System.Windows.Forms.Label();
            this.LabelWorkingDir = new System.Windows.Forms.Label();
            this.LabelOpenDataDir = new System.Windows.Forms.Label();
            this.LabelOpenProgramDir = new System.Windows.Forms.Label();
            this.LabelOpenWorkingDir = new System.Windows.Forms.Label();
            this.LabelVersionInfo = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.LableStatusGlobal = new System.Windows.Forms.Label();
            this.BoxChart = new System.Windows.Forms.GroupBox();
            this.ButtonShiftRight = new System.Windows.Forms.Button();
            this.ButtonScaleZero = new System.Windows.Forms.Button();
            this.ButtonYShiftDown = new System.Windows.Forms.Button();
            this.ButtonYShiftUp = new System.Windows.Forms.Button();
            this.ButtonYZoomIn = new System.Windows.Forms.Button();
            this.ButtonScalePlus = new System.Windows.Forms.Button();
            this.LabelPlotSpeed = new System.Windows.Forms.Label();
            this.LabelPlotCount = new System.Windows.Forms.Label();
            this.ChartFFT = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ButtonYZoomOut = new System.Windows.Forms.Button();
            this.ButtonScaleMinus = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ButtonShiftLeft = new System.Windows.Forms.Button();
            this.TextBoxFreqMax = new System.Windows.Forms.TextBox();
            this.TextBoxFreqMin = new System.Windows.Forms.TextBox();
            this.TimerRxSpeed = new System.Windows.Forms.Timer(this.components);
            this.T1 = new System.Windows.Forms.Timer(this.components);
            this.BGFillData = new System.ComponentModel.BackgroundWorker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BGFillData2 = new System.ComponentModel.BackgroundWorker();
            this.BgFeatureWrite = new System.ComponentModel.BackgroundWorker();
            this.BoxConfig.SuspendLayout();
            this.BoxRxTx.SuspendLayout();
            this.GPLearn.SuspendLayout();
            this.BoxInformation.SuspendLayout();
            this.BoxChart.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartFFT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BoxConfig
            // 
            this.BoxConfig.Controls.Add(this.ButtonProgramRP);
            this.BoxConfig.Controls.Add(this.ButtonStopServer);
            this.BoxConfig.Controls.Add(this.ButtonStartServer);
            this.BoxConfig.Controls.Add(this.label2);
            this.BoxConfig.Controls.Add(this.ButtonCheckServer);
            this.BoxConfig.Controls.Add(this.label6);
            this.BoxConfig.Controls.Add(this.label1);
            this.BoxConfig.Controls.Add(this.TextBoxRemotePort1);
            this.BoxConfig.Controls.Add(this.TextBoxLocalIP1);
            this.BoxConfig.Controls.Add(this.TextBoxRemoteIP1);
            this.BoxConfig.Location = new System.Drawing.Point(12, 136);
            this.BoxConfig.Name = "BoxConfig";
            this.BoxConfig.Size = new System.Drawing.Size(237, 314);
            this.BoxConfig.TabIndex = 0;
            this.BoxConfig.TabStop = false;
            this.BoxConfig.Text = "UDP client config";
            // 
            // ButtonProgramRP
            // 
            this.ButtonProgramRP.Enabled = false;
            this.ButtonProgramRP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonProgramRP.Location = new System.Drawing.Point(6, 285);
            this.ButtonProgramRP.Name = "ButtonProgramRP";
            this.ButtonProgramRP.Size = new System.Drawing.Size(210, 23);
            this.ButtonProgramRP.TabIndex = 0;
            this.ButtonProgramRP.Text = "program RedPitaya";
            this.ButtonProgramRP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonProgramRP.UseVisualStyleBackColor = true;
            this.ButtonProgramRP.Click += new System.EventHandler(this.ButtonProgramRP_Click);
            // 
            // ButtonStopServer
            // 
            this.ButtonStopServer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonStopServer.Location = new System.Drawing.Point(131, 256);
            this.ButtonStopServer.Name = "ButtonStopServer";
            this.ButtonStopServer.Size = new System.Drawing.Size(85, 23);
            this.ButtonStopServer.TabIndex = 0;
            this.ButtonStopServer.Text = "stop UDP";
            this.ButtonStopServer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonStopServer.UseVisualStyleBackColor = true;
            this.ButtonStopServer.Click += new System.EventHandler(this.ButtonStopServer_Click);
            // 
            // ButtonStartServer
            // 
            this.ButtonStartServer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonStartServer.Location = new System.Drawing.Point(6, 256);
            this.ButtonStartServer.Name = "ButtonStartServer";
            this.ButtonStartServer.Size = new System.Drawing.Size(85, 23);
            this.ButtonStartServer.TabIndex = 0;
            this.ButtonStartServer.Text = "start UDP";
            this.ButtonStartServer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonStartServer.UseVisualStyleBackColor = true;
            this.ButtonStartServer.Click += new System.EventHandler(this.ButtonStartServer_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sensor port";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ButtonCheckServer
            // 
            this.ButtonCheckServer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonCheckServer.Location = new System.Drawing.Point(6, 227);
            this.ButtonCheckServer.Name = "ButtonCheckServer";
            this.ButtonCheckServer.Size = new System.Drawing.Size(210, 23);
            this.ButtonCheckServer.TabIndex = 0;
            this.ButtonCheckServer.Text = "check server connection";
            this.ButtonCheckServer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonCheckServer.UseVisualStyleBackColor = true;
            this.ButtonCheckServer.Click += new System.EventHandler(this.ButtonCheckServer_Click);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(6, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "local IP-address 1";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sensor 1 IP-address";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TextBoxRemotePort1
            // 
            this.TextBoxRemotePort1.Location = new System.Drawing.Point(131, 46);
            this.TextBoxRemotePort1.Name = "TextBoxRemotePort1";
            this.TextBoxRemotePort1.Size = new System.Drawing.Size(85, 20);
            this.TextBoxRemotePort1.TabIndex = 1;
            this.TextBoxRemotePort1.Text = "0";
            // 
            // TextBoxLocalIP1
            // 
            this.TextBoxLocalIP1.Location = new System.Drawing.Point(131, 72);
            this.TextBoxLocalIP1.Name = "TextBoxLocalIP1";
            this.TextBoxLocalIP1.Size = new System.Drawing.Size(85, 20);
            this.TextBoxLocalIP1.TabIndex = 1;
            this.TextBoxLocalIP1.Text = "127.0.0.1";
            // 
            // TextBoxRemoteIP1
            // 
            this.TextBoxRemoteIP1.Location = new System.Drawing.Point(131, 20);
            this.TextBoxRemoteIP1.Name = "TextBoxRemoteIP1";
            this.TextBoxRemoteIP1.Size = new System.Drawing.Size(85, 20);
            this.TextBoxRemoteIP1.TabIndex = 1;
            this.TextBoxRemoteIP1.Text = "0.0.0.0";
            // 
            // BoxRxTx
            // 
            this.BoxRxTx.Controls.Add(this.GPLearn);
            this.BoxRxTx.Controls.Add(this.ButtonStartADC);
            this.BoxRxTx.Controls.Add(this.ButtonStartFFT);
            this.BoxRxTx.Controls.Add(this.ButtonStartMeasure);
            this.BoxRxTx.Controls.Add(this.LabelRxByteCounter);
            this.BoxRxTx.Controls.Add(this.LabelRXcount);
            this.BoxRxTx.Controls.Add(this.CBSaveLearningData);
            this.BoxRxTx.Controls.Add(this.label4);
            this.BoxRxTx.Controls.Add(this.ButtonCopyClip);
            this.BoxRxTx.Controls.Add(this.ButtonRxReset);
            this.BoxRxTx.Controls.Add(this.TextBoxRX);
            this.BoxRxTx.Controls.Add(this.ButtonTX);
            this.BoxRxTx.Controls.Add(this.TextBoxTX);
            this.BoxRxTx.Enabled = false;
            this.BoxRxTx.Location = new System.Drawing.Point(255, 136);
            this.BoxRxTx.Name = "BoxRxTx";
            this.BoxRxTx.Size = new System.Drawing.Size(220, 426);
            this.BoxRxTx.TabIndex = 1;
            this.BoxRxTx.TabStop = false;
            this.BoxRxTx.Text = "Send / Receive";
            // 
            // GPLearn
            // 
            this.GPLearn.Controls.Add(this.BoxMaxFiles);
            this.GPLearn.Controls.Add(this.label3);
            this.GPLearn.Controls.Add(this.label8);
            this.GPLearn.Controls.Add(this.CbLearnObject);
            this.GPLearn.Controls.Add(this.TbComment);
            this.GPLearn.Enabled = false;
            this.GPLearn.Location = new System.Drawing.Point(6, 104);
            this.GPLearn.Name = "GPLearn";
            this.GPLearn.Size = new System.Drawing.Size(208, 126);
            this.GPLearn.TabIndex = 12;
            this.GPLearn.TabStop = false;
            this.GPLearn.Text = "learn configs";
            // 
            // BoxMaxFiles
            // 
            this.BoxMaxFiles.Location = new System.Drawing.Point(130, 57);
            this.BoxMaxFiles.Name = "BoxMaxFiles";
            this.BoxMaxFiles.Size = new System.Drawing.Size(72, 20);
            this.BoxMaxFiles.TabIndex = 1;
            this.BoxMaxFiles.Text = "5";
            this.BoxMaxFiles.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "object:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "measurements:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // CbLearnObject
            // 
            this.CbLearnObject.FormattingEnabled = true;
            this.CbLearnObject.Location = new System.Drawing.Point(130, 13);
            this.CbLearnObject.Name = "CbLearnObject";
            this.CbLearnObject.Size = new System.Drawing.Size(72, 21);
            this.CbLearnObject.TabIndex = 12;
            // 
            // TbComment
            // 
            this.TbComment.Location = new System.Drawing.Point(6, 100);
            this.TbComment.Name = "TbComment";
            this.TbComment.Size = new System.Drawing.Size(196, 20);
            this.TbComment.TabIndex = 1;
            this.TbComment.TextChanged += new System.EventHandler(this.TextBoxTX_TextChanged);
            // 
            // ButtonStartADC
            // 
            this.ButtonStartADC.Appearance = System.Windows.Forms.Appearance.Button;
            this.ButtonStartADC.Location = new System.Drawing.Point(6, 265);
            this.ButtonStartADC.Name = "ButtonStartADC";
            this.ButtonStartADC.Size = new System.Drawing.Size(103, 23);
            this.ButtonStartADC.TabIndex = 11;
            this.ButtonStartADC.Text = "start ADC";
            this.ButtonStartADC.UseVisualStyleBackColor = true;
            this.ButtonStartADC.CheckedChanged += new System.EventHandler(this.ButtonStartX_Click);
            // 
            // ButtonStartFFT
            // 
            this.ButtonStartFFT.Appearance = System.Windows.Forms.Appearance.Button;
            this.ButtonStartFFT.Location = new System.Drawing.Point(6, 236);
            this.ButtonStartFFT.Name = "ButtonStartFFT";
            this.ButtonStartFFT.Size = new System.Drawing.Size(103, 23);
            this.ButtonStartFFT.TabIndex = 11;
            this.ButtonStartFFT.Text = "start FFT";
            this.ButtonStartFFT.UseVisualStyleBackColor = true;
            this.ButtonStartFFT.CheckedChanged += new System.EventHandler(this.ButtonStartX_Click);
            // 
            // ButtonStartMeasure
            // 
            this.ButtonStartMeasure.Appearance = System.Windows.Forms.Appearance.Button;
            this.ButtonStartMeasure.Location = new System.Drawing.Point(115, 236);
            this.ButtonStartMeasure.Name = "ButtonStartMeasure";
            this.ButtonStartMeasure.Size = new System.Drawing.Size(99, 23);
            this.ButtonStartMeasure.TabIndex = 11;
            this.ButtonStartMeasure.Text = "start measure";
            this.ButtonStartMeasure.UseVisualStyleBackColor = true;
            this.ButtonStartMeasure.CheckedChanged += new System.EventHandler(this.ButtonStartX_Click);
            // 
            // LabelRxByteCounter
            // 
            this.LabelRxByteCounter.Location = new System.Drawing.Point(76, 403);
            this.LabelRxByteCounter.Name = "LabelRxByteCounter";
            this.LabelRxByteCounter.Size = new System.Drawing.Size(59, 20);
            this.LabelRxByteCounter.TabIndex = 1;
            this.LabelRxByteCounter.Text = "0";
            this.LabelRxByteCounter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LabelRXcount
            // 
            this.LabelRXcount.Location = new System.Drawing.Point(76, 379);
            this.LabelRXcount.Name = "LabelRXcount";
            this.LabelRXcount.Size = new System.Drawing.Size(59, 20);
            this.LabelRXcount.TabIndex = 1;
            this.LabelRXcount.Text = "0";
            this.LabelRXcount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CBSaveLearningData
            // 
            this.CBSaveLearningData.AutoSize = true;
            this.CBSaveLearningData.Location = new System.Drawing.Point(6, 81);
            this.CBSaveLearningData.Name = "CBSaveLearningData";
            this.CBSaveLearningData.Size = new System.Drawing.Size(49, 17);
            this.CBSaveLearningData.TabIndex = 9;
            this.CBSaveLearningData.Text = "learn";
            this.CBSaveLearningData.UseVisualStyleBackColor = true;
            this.CBSaveLearningData.CheckedChanged += new System.EventHandler(this.CBSaveLearningData_CheckedChanged);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(6, 403);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "RX count:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ButtonCopyClip
            // 
            this.ButtonCopyClip.Location = new System.Drawing.Point(303, 378);
            this.ButtonCopyClip.Name = "ButtonCopyClip";
            this.ButtonCopyClip.Size = new System.Drawing.Size(67, 22);
            this.ButtonCopyClip.TabIndex = 0;
            this.ButtonCopyClip.Text = "cpy to clip";
            this.ButtonCopyClip.UseVisualStyleBackColor = true;
            this.ButtonCopyClip.Click += new System.EventHandler(this.ButtonCopyClip_Click);
            // 
            // ButtonRxReset
            // 
            this.ButtonRxReset.Location = new System.Drawing.Point(6, 378);
            this.ButtonRxReset.Name = "ButtonRxReset";
            this.ButtonRxReset.Size = new System.Drawing.Size(64, 22);
            this.ButtonRxReset.TabIndex = 0;
            this.ButtonRxReset.Text = "clear RX";
            this.ButtonRxReset.UseVisualStyleBackColor = true;
            this.ButtonRxReset.Click += new System.EventHandler(this.ButtonRX_Click);
            // 
            // TextBoxRX
            // 
            this.TextBoxRX.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxRX.Location = new System.Drawing.Point(6, 294);
            this.TextBoxRX.Name = "TextBoxRX";
            this.TextBoxRX.Size = new System.Drawing.Size(208, 78);
            this.TextBoxRX.TabIndex = 2;
            this.TextBoxRX.Text = "";
            // 
            // ButtonTX
            // 
            this.ButtonTX.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonTX.Location = new System.Drawing.Point(6, 48);
            this.ButtonTX.Name = "ButtonTX";
            this.ButtonTX.Size = new System.Drawing.Size(103, 23);
            this.ButtonTX.TabIndex = 0;
            this.ButtonTX.Text = "send command";
            this.ButtonTX.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonTX.UseVisualStyleBackColor = true;
            this.ButtonTX.Click += new System.EventHandler(this.ButtonTX_Click);
            // 
            // TextBoxTX
            // 
            this.TextBoxTX.Location = new System.Drawing.Point(6, 20);
            this.TextBoxTX.Name = "TextBoxTX";
            this.TextBoxTX.Size = new System.Drawing.Size(208, 20);
            this.TextBoxTX.TabIndex = 1;
            this.TextBoxTX.TextChanged += new System.EventHandler(this.TextBoxTX_TextChanged);
            // 
            // ButtonStartClient
            // 
            this.ButtonStartClient.Appearance = System.Windows.Forms.Appearance.Button;
            this.ButtonStartClient.AutoSize = true;
            this.ButtonStartClient.Location = new System.Drawing.Point(82, 538);
            this.ButtonStartClient.Name = "ButtonStartClient";
            this.ButtonStartClient.Size = new System.Drawing.Size(65, 23);
            this.ButtonStartClient.TabIndex = 2;
            this.ButtonStartClient.Text = "start client";
            this.ButtonStartClient.UseVisualStyleBackColor = true;
            this.ButtonStartClient.CheckedChanged += new System.EventHandler(this.ButtonStartClient_CheckedChanged);
            // 
            // ButtonExit
            // 
            this.ButtonExit.Location = new System.Drawing.Point(12, 538);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(64, 23);
            this.ButtonExit.TabIndex = 3;
            this.ButtonExit.Text = "exit app";
            this.ButtonExit.UseVisualStyleBackColor = true;
            this.ButtonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // BoxInformation
            // 
            this.BoxInformation.Controls.Add(this.LabelDataDir);
            this.BoxInformation.Controls.Add(this.LabelProgramDir);
            this.BoxInformation.Controls.Add(this.LabelWorkingDir);
            this.BoxInformation.Controls.Add(this.LabelOpenDataDir);
            this.BoxInformation.Controls.Add(this.LabelOpenProgramDir);
            this.BoxInformation.Controls.Add(this.LabelOpenWorkingDir);
            this.BoxInformation.Controls.Add(this.LabelVersionInfo);
            this.BoxInformation.Controls.Add(this.label12);
            this.BoxInformation.Controls.Add(this.label5);
            this.BoxInformation.Location = new System.Drawing.Point(255, 12);
            this.BoxInformation.Name = "BoxInformation";
            this.BoxInformation.Size = new System.Drawing.Size(757, 118);
            this.BoxInformation.TabIndex = 5;
            this.BoxInformation.TabStop = false;
            this.BoxInformation.Text = "Information";
            // 
            // LabelDataDir
            // 
            this.LabelDataDir.AutoSize = true;
            this.LabelDataDir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelDataDir.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDataDir.Location = new System.Drawing.Point(98, 100);
            this.LabelDataDir.Name = "LabelDataDir";
            this.LabelDataDir.Size = new System.Drawing.Size(51, 15);
            this.LabelDataDir.TabIndex = 1;
            this.LabelDataDir.Text = "DataDir";
            this.LabelDataDir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelProgramDir
            // 
            this.LabelProgramDir.AutoSize = true;
            this.LabelProgramDir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelProgramDir.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelProgramDir.Location = new System.Drawing.Point(97, 80);
            this.LabelProgramDir.Name = "LabelProgramDir";
            this.LabelProgramDir.Size = new System.Drawing.Size(51, 15);
            this.LabelProgramDir.TabIndex = 1;
            this.LabelProgramDir.Text = "ProgDir";
            this.LabelProgramDir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelWorkingDir
            // 
            this.LabelWorkingDir.AutoSize = true;
            this.LabelWorkingDir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelWorkingDir.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelWorkingDir.Location = new System.Drawing.Point(97, 60);
            this.LabelWorkingDir.Name = "LabelWorkingDir";
            this.LabelWorkingDir.Size = new System.Drawing.Size(69, 15);
            this.LabelWorkingDir.TabIndex = 1;
            this.LabelWorkingDir.Text = "WorkingDir";
            this.LabelWorkingDir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LabelWorkingDir.Click += new System.EventHandler(this.LabelWorkingDir_Click);
            // 
            // LabelOpenDataDir
            // 
            this.LabelOpenDataDir.Location = new System.Drawing.Point(7, 95);
            this.LabelOpenDataDir.Name = "LabelOpenDataDir";
            this.LabelOpenDataDir.Size = new System.Drawing.Size(85, 20);
            this.LabelOpenDataDir.TabIndex = 1;
            this.LabelOpenDataDir.Text = "Data Dir:";
            this.LabelOpenDataDir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LabelOpenDataDir.Click += new System.EventHandler(this.LabelOpenDataDir_Click);
            // 
            // LabelOpenProgramDir
            // 
            this.LabelOpenProgramDir.Location = new System.Drawing.Point(7, 75);
            this.LabelOpenProgramDir.Name = "LabelOpenProgramDir";
            this.LabelOpenProgramDir.Size = new System.Drawing.Size(85, 20);
            this.LabelOpenProgramDir.TabIndex = 1;
            this.LabelOpenProgramDir.Text = "Prog Dir:";
            this.LabelOpenProgramDir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LabelOpenProgramDir.Click += new System.EventHandler(this.LabelOpenProgramDir_Click);
            // 
            // LabelOpenWorkingDir
            // 
            this.LabelOpenWorkingDir.Location = new System.Drawing.Point(7, 55);
            this.LabelOpenWorkingDir.Name = "LabelOpenWorkingDir";
            this.LabelOpenWorkingDir.Size = new System.Drawing.Size(84, 20);
            this.LabelOpenWorkingDir.TabIndex = 1;
            this.LabelOpenWorkingDir.Text = "Working dir:";
            this.LabelOpenWorkingDir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LabelOpenWorkingDir.Click += new System.EventHandler(this.LabelOpenWorkingDir_Click);
            // 
            // LabelVersionInfo
            // 
            this.LabelVersionInfo.AutoSize = true;
            this.LabelVersionInfo.Location = new System.Drawing.Point(153, 38);
            this.LabelVersionInfo.Name = "LabelVersionInfo";
            this.LabelVersionInfo.Size = new System.Drawing.Size(13, 13);
            this.LabelVersionInfo.TabIndex = 0;
            this.LabelVersionInfo.Text = "0";
            this.LabelVersionInfo.Click += new System.EventHandler(this.LabelVersionInfo_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Red Pitaya SW Version:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "UAS Frankfurt - FB2";
            // 
            // LableStatusGlobal
            // 
            this.LableStatusGlobal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LableStatusGlobal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LableStatusGlobal.Location = new System.Drawing.Point(15, 500);
            this.LableStatusGlobal.Name = "LableStatusGlobal";
            this.LableStatusGlobal.Size = new System.Drawing.Size(237, 22);
            this.LableStatusGlobal.TabIndex = 1;
            this.LableStatusGlobal.Text = "Status: ";
            this.LableStatusGlobal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BoxChart
            // 
            this.BoxChart.Controls.Add(this.ButtonShiftRight);
            this.BoxChart.Controls.Add(this.ButtonScaleZero);
            this.BoxChart.Controls.Add(this.ButtonYShiftDown);
            this.BoxChart.Controls.Add(this.ButtonYShiftUp);
            this.BoxChart.Controls.Add(this.ButtonYZoomIn);
            this.BoxChart.Controls.Add(this.ButtonScalePlus);
            this.BoxChart.Controls.Add(this.LabelPlotSpeed);
            this.BoxChart.Controls.Add(this.LabelPlotCount);
            this.BoxChart.Controls.Add(this.ChartFFT);
            this.BoxChart.Controls.Add(this.ButtonYZoomOut);
            this.BoxChart.Controls.Add(this.ButtonScaleMinus);
            this.BoxChart.Controls.Add(this.label11);
            this.BoxChart.Controls.Add(this.label10);
            this.BoxChart.Controls.Add(this.ButtonShiftLeft);
            this.BoxChart.Controls.Add(this.TextBoxFreqMax);
            this.BoxChart.Controls.Add(this.TextBoxFreqMin);
            this.BoxChart.Enabled = false;
            this.BoxChart.Location = new System.Drawing.Point(481, 136);
            this.BoxChart.Name = "BoxChart";
            this.BoxChart.Size = new System.Drawing.Size(531, 427);
            this.BoxChart.TabIndex = 6;
            this.BoxChart.TabStop = false;
            this.BoxChart.Text = "Data ADC / FFT";
            // 
            // ButtonShiftRight
            // 
            this.ButtonShiftRight.Location = new System.Drawing.Point(272, 400);
            this.ButtonShiftRight.Name = "ButtonShiftRight";
            this.ButtonShiftRight.Size = new System.Drawing.Size(36, 21);
            this.ButtonShiftRight.TabIndex = 7;
            this.ButtonShiftRight.Text = ">>";
            this.ButtonShiftRight.UseVisualStyleBackColor = true;
            this.ButtonShiftRight.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // ButtonScaleZero
            // 
            this.ButtonScaleZero.Location = new System.Drawing.Point(230, 365);
            this.ButtonScaleZero.Name = "ButtonScaleZero";
            this.ButtonScaleZero.Size = new System.Drawing.Size(36, 21);
            this.ButtonScaleZero.TabIndex = 7;
            this.ButtonScaleZero.Text = "0";
            this.ButtonScaleZero.UseVisualStyleBackColor = true;
            this.ButtonScaleZero.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // ButtonYShiftDown
            // 
            this.ButtonYShiftDown.Location = new System.Drawing.Point(470, 400);
            this.ButtonYShiftDown.Name = "ButtonYShiftDown";
            this.ButtonYShiftDown.Size = new System.Drawing.Size(36, 21);
            this.ButtonYShiftDown.TabIndex = 7;
            this.ButtonYShiftDown.Text = "V";
            this.ButtonYShiftDown.UseVisualStyleBackColor = true;
            this.ButtonYShiftDown.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // ButtonYShiftUp
            // 
            this.ButtonYShiftUp.Location = new System.Drawing.Point(470, 365);
            this.ButtonYShiftUp.Name = "ButtonYShiftUp";
            this.ButtonYShiftUp.Size = new System.Drawing.Size(36, 21);
            this.ButtonYShiftUp.TabIndex = 7;
            this.ButtonYShiftUp.Text = "A";
            this.ButtonYShiftUp.UseVisualStyleBackColor = true;
            this.ButtonYShiftUp.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // ButtonYZoomIn
            // 
            this.ButtonYZoomIn.Location = new System.Drawing.Point(428, 365);
            this.ButtonYZoomIn.Name = "ButtonYZoomIn";
            this.ButtonYZoomIn.Size = new System.Drawing.Size(36, 21);
            this.ButtonYZoomIn.TabIndex = 7;
            this.ButtonYZoomIn.Text = "++";
            this.ButtonYZoomIn.UseVisualStyleBackColor = true;
            this.ButtonYZoomIn.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // ButtonScalePlus
            // 
            this.ButtonScalePlus.Location = new System.Drawing.Point(272, 365);
            this.ButtonScalePlus.Name = "ButtonScalePlus";
            this.ButtonScalePlus.Size = new System.Drawing.Size(36, 21);
            this.ButtonScalePlus.TabIndex = 7;
            this.ButtonScalePlus.Text = "++";
            this.ButtonScalePlus.UseVisualStyleBackColor = true;
            this.ButtonScalePlus.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // LabelPlotSpeed
            // 
            this.LabelPlotSpeed.Location = new System.Drawing.Point(314, 400);
            this.LabelPlotSpeed.Name = "LabelPlotSpeed";
            this.LabelPlotSpeed.Size = new System.Drawing.Size(55, 20);
            this.LabelPlotSpeed.TabIndex = 1;
            this.LabelPlotSpeed.Text = "0";
            this.LabelPlotSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LabelPlotCount
            // 
            this.LabelPlotCount.Location = new System.Drawing.Point(314, 365);
            this.LabelPlotCount.Name = "LabelPlotCount";
            this.LabelPlotCount.Size = new System.Drawing.Size(55, 20);
            this.LabelPlotCount.TabIndex = 1;
            this.LabelPlotCount.Text = "0";
            this.LabelPlotCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ChartFFT
            // 
            this.ChartFFT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea3.AxisY.Maximum = 1000D;
            chartArea3.AxisY.Minimum = 0D;
            chartArea3.Name = "ChartArea1";
            this.ChartFFT.ChartAreas.Add(chartArea3);
            this.ChartFFT.Location = new System.Drawing.Point(6, 19);
            this.ChartFFT.Name = "ChartFFT";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.IsVisibleInLegend = false;
            series3.Name = "Series1";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            series3.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
            this.ChartFFT.Series.Add(series3);
            this.ChartFFT.Size = new System.Drawing.Size(519, 338);
            this.ChartFFT.TabIndex = 0;
            this.ChartFFT.Text = "ChartFFT";
            // 
            // ButtonYZoomOut
            // 
            this.ButtonYZoomOut.Location = new System.Drawing.Point(428, 400);
            this.ButtonYZoomOut.Name = "ButtonYZoomOut";
            this.ButtonYZoomOut.Size = new System.Drawing.Size(36, 21);
            this.ButtonYZoomOut.TabIndex = 7;
            this.ButtonYZoomOut.Text = "--";
            this.ButtonYZoomOut.UseVisualStyleBackColor = true;
            this.ButtonYZoomOut.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // ButtonScaleMinus
            // 
            this.ButtonScaleMinus.Location = new System.Drawing.Point(188, 365);
            this.ButtonScaleMinus.Name = "ButtonScaleMinus";
            this.ButtonScaleMinus.Size = new System.Drawing.Size(36, 21);
            this.ButtonScaleMinus.TabIndex = 7;
            this.ButtonScaleMinus.Text = "--";
            this.ButtonScaleMinus.UseVisualStyleBackColor = true;
            this.ButtonScaleMinus.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 407);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "max. frequency";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "min frequency";
            // 
            // ButtonShiftLeft
            // 
            this.ButtonShiftLeft.Location = new System.Drawing.Point(188, 400);
            this.ButtonShiftLeft.Name = "ButtonShiftLeft";
            this.ButtonShiftLeft.Size = new System.Drawing.Size(36, 21);
            this.ButtonShiftLeft.TabIndex = 7;
            this.ButtonShiftLeft.Text = "<<";
            this.ButtonShiftLeft.UseVisualStyleBackColor = true;
            this.ButtonShiftLeft.Click += new System.EventHandler(this.ButtonScaleX);
            // 
            // TextBoxFreqMax
            // 
            this.TextBoxFreqMax.Location = new System.Drawing.Point(109, 401);
            this.TextBoxFreqMax.Name = "TextBoxFreqMax";
            this.TextBoxFreqMax.ReadOnly = true;
            this.TextBoxFreqMax.Size = new System.Drawing.Size(36, 20);
            this.TextBoxFreqMax.TabIndex = 1;
            this.TextBoxFreqMax.Text = "2000";
            this.TextBoxFreqMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TextBoxFreqMin
            // 
            this.TextBoxFreqMin.Location = new System.Drawing.Point(109, 366);
            this.TextBoxFreqMin.Name = "TextBoxFreqMin";
            this.TextBoxFreqMin.ReadOnly = true;
            this.TextBoxFreqMin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TextBoxFreqMin.Size = new System.Drawing.Size(36, 20);
            this.TextBoxFreqMin.TabIndex = 1;
            this.TextBoxFreqMin.Text = "1000";
            this.TextBoxFreqMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TimerRxSpeed
            // 
            this.TimerRxSpeed.Tick += new System.EventHandler(this.TimerRxSpeed_Tick);
            // 
            // T1
            // 
            this.T1.Tick += new System.EventHandler(this.T1_Tick);
            // 
            // BGFillData
            // 
            this.BGFillData.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BGFillData_DoWork);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::UDP_Client.Properties.Resources.UAS_Logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 118);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // BGFillData2
            // 
            this.BGFillData2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BGFillData2_DoWork);
            // 
            // BgFeatureWrite
            // 
            this.BgFeatureWrite.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BgFeatureWrite_DoWork);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 574);
            this.Controls.Add(this.BoxChart);
            this.Controls.Add(this.LableStatusGlobal);
            this.Controls.Add(this.BoxInformation);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ButtonExit);
            this.Controls.Add(this.ButtonStartClient);
            this.Controls.Add(this.BoxRxTx);
            this.Controls.Add(this.BoxConfig);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "UDP client - UAS Frankfurt @2020";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.BoxConfig.ResumeLayout(false);
            this.BoxConfig.PerformLayout();
            this.BoxRxTx.ResumeLayout(false);
            this.BoxRxTx.PerformLayout();
            this.GPLearn.ResumeLayout(false);
            this.GPLearn.PerformLayout();
            this.BoxInformation.ResumeLayout(false);
            this.BoxInformation.PerformLayout();
            this.BoxChart.ResumeLayout(false);
            this.BoxChart.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartFFT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox BoxConfig;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TextBoxRemoteIP1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBoxRemotePort1;
        private System.Windows.Forms.GroupBox BoxRxTx;
        private System.Windows.Forms.Button ButtonTX;
        private System.Windows.Forms.TextBox TextBoxTX;
        private System.Windows.Forms.RichTextBox TextBoxRX;
        private System.Windows.Forms.Button ButtonRxReset;
        private System.Windows.Forms.CheckBox ButtonStartClient;
        private System.Windows.Forms.Button ButtonExit;
        private System.Windows.Forms.Label LabelRXcount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox BoxInformation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TextBoxLocalIP1;
        private System.Windows.Forms.Button ButtonCopyClip;
        private System.Windows.Forms.Button ButtonStopServer;
        private System.Windows.Forms.Button ButtonStartServer;
        private System.Windows.Forms.Button ButtonCheckServer;
        private System.Windows.Forms.Label LabelVersionInfo;
        private System.Windows.Forms.Button ButtonProgramRP;
        private System.Windows.Forms.Label LabelWorkingDir;
        private System.Windows.Forms.Label LabelOpenWorkingDir;
        private System.Windows.Forms.Label LabelProgramDir;
        private System.Windows.Forms.Label LabelOpenProgramDir;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label LableStatusGlobal;
        private System.Windows.Forms.GroupBox BoxChart;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartFFT;
        private System.Windows.Forms.Label LabelDataDir;
        private System.Windows.Forms.Label LabelOpenDataDir;
        private System.Windows.Forms.Timer TimerRxSpeed;
        private System.Windows.Forms.Button ButtonScaleMinus;
        private System.Windows.Forms.Button ButtonScalePlus;
        private System.Windows.Forms.Button ButtonScaleZero;
        private System.Windows.Forms.Button ButtonShiftLeft;
        private System.Windows.Forms.Button ButtonShiftRight;
        private System.Windows.Forms.TextBox TextBoxFreqMin;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TextBoxFreqMax;
        private System.Windows.Forms.Label LabelPlotCount;
        private System.Windows.Forms.Timer T1;
        private System.Windows.Forms.Label LabelPlotSpeed;
        private System.ComponentModel.BackgroundWorker BGFillData;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox BoxMaxFiles;
        private System.Windows.Forms.CheckBox ButtonStartFFT;
        private System.Windows.Forms.CheckBox ButtonStartMeasure;
        private System.Windows.Forms.CheckBox CBSaveLearningData;
        private System.Windows.Forms.Label LabelRxByteCounter;
        private System.Windows.Forms.CheckBox ButtonStartADC;
        private System.ComponentModel.BackgroundWorker BGFillData2;
        private System.Windows.Forms.TextBox TbComment;
        private System.ComponentModel.BackgroundWorker BgFeatureWrite;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ButtonYZoomIn;
        private System.Windows.Forms.Button ButtonYZoomOut;
        private System.Windows.Forms.Button ButtonYShiftUp;
        private System.Windows.Forms.Button ButtonYShiftDown;
        private System.Windows.Forms.ComboBox CbLearnObject;
        private System.Windows.Forms.GroupBox GPLearn;
        private System.Windows.Forms.Label label12;
    }
}

